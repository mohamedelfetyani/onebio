<?php defined('ALTUMCODE') || die() ?>

<div data-link-id="<?= $data->link->link_id ?>" class="col-12 my-3 d-flex justify-content-center">
    <blockquote class="instagram-media" data-instgrm-permalink="<?= $data->link->location_url ?>" data-instgrm-version="13">
    </blockquote>
    <script async src="//www.instagram.com/embed.js"></script>
</div>

