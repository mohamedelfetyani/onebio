<?php defined('ALTUMCODE') || die() ?>

<div data-link-id="<?= $data->link->link_id ?>" class="col-12 my-3 d-flex justify-content-center">
    <blockquote class="twitter-tweet">
        <a href="<?= $data->link->location_url ?>"></a>
        <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
    </blockquote>
</div>
