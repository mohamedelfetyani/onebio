<?php

return [
    'lato' => [
        'name' => 'Lato',
        'font-family' => 'Lato'
    ],

    'open-sans' => [
        'name' => 'Open Sans',
        'font-family' => 'Open+Sans'
    ],

    'montserrat' => [
        'name' => 'Montserrat',
        'font-family' => 'Montserrat'
    ],

    'karla' => [
        'name' => 'Karla',
        'font-family' => 'Karla'
    ],

    'inconsolata' => [
        'name' => 'Inconsolata',
        'font-family' => 'Inconsolata'
    ],
];
