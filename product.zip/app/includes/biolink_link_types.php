<?php

return [
    'link',
    'text',
    'image',
    'mail',
    'soundcloud',
    'spotify',
    'youtube',
    'twitch',
    'vimeo',
    'tiktok',

    'applemusic',
    'tidal',
    'anchor',
    'twitter_tweet',
    'instagram_media',
    'rss_feed',
    'custom_html',
    'vcard',
    'image_grid',
    'divider'
];

