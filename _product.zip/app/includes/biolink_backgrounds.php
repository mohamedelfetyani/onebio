<?php

return [
    'preset' => [
        'one',
        'two',
        'three',
        'four',
        'five',
        'six'
    ],

    'gradient' => [],

    'color' => [],

    'image' => []
];
